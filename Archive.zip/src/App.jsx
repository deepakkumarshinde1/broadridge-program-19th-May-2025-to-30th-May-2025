// import (optional)

import Counter from "./components/Counter";

// comp (class / function)
function App() {
  let counterList = [1, 2, 3];
  return (
    <section>
      {counterList.map((value, index) => {
        return <Counter key={index} counter={value} counterName={index} />;
      })}
    </section>
  );
}

export default App;

// JSX => Javascript XML

// it has only one parent
// elements must be closed
// class => className
// for => htmlFor
// javascript = {} => JSX string interpolation syntax
