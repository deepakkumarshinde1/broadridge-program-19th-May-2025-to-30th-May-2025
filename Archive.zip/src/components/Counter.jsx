function Counter(props) {
  let count = props.counter;
  console.log(props);
  return (
    <section>
      <h1>
        Counter:{props.counterName} {count}
      </h1>
    </section>
  );
}

export default Counter;
