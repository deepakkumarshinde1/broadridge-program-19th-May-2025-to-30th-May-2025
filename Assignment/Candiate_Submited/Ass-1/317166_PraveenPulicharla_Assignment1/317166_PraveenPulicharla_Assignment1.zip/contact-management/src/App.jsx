import { useState,useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import  ContactForm from'./component/ContactForm.jsx';
import  ContactItem from'./component/ContactItem';
import  ContactList from'./component/ContactList';

function App() {

  let [contact, setContact] = useState({
      name: "",
      email: "",
      phone: "",
    });
    let [contacts, setContacts] = useState([]);
    let [editContact,setEditContact] = useState(null);
    let [viewContact,setViewContact] = useState(null);
  
    //Add Contacts to an Array
    let addContact = () => {
        if(editContact!==null){
          let updatedContacts = [...contacts];
          updatedContacts[editContact] = contact;
          setContacts(updatedContacts);
          setEditContact(null);
        }else
           setContacts([...contacts, contact]);
    }

  // Log contacts whenever it changes
  useEffect(() => {
    console.log("Contacts list:", contacts);
  }, [contacts]);

  //Delete Contacts
   let deleteContact = (index) => {
       let updatedContacts =[...contacts];
       updatedContacts.splice(index,1);
       setContacts(updatedContacts);
       // Resetting the View Contact when the Contact is being Deleted
       setViewContact("");

   }

   //view Contact
   let viewContactDetails = (index) => {
        setViewContact(contacts[index]);
   }


  return (
    <>
      <h1> Welcome to Contact Management</h1>
      <ContactForm
      contact={contact}
      setContact={setContact}
      addContact={addContact}
      />
      {contacts.length>0 && <ContactList contacts={contacts} deleteContact={deleteContact}
      onEdit={(index) => setEditContact(index)}
      onView={viewContactDetails}/>}

     {viewContact && <ContactItem viewContact={viewContact}/>}
    </>
  )
}

export default App
