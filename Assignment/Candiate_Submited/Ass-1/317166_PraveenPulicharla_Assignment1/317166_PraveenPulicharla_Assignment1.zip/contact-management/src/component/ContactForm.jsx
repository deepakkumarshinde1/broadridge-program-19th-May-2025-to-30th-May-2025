import { useState } from "react";

function ContactForm(props) {

  let { contact, setContact, addContact } = props;

  let handleChange = (event)=>{
    let {id,value} = event.target;
    setContact(contact => ({
      ...contact,
      [id]: value
    }));

  };

  
  return (
    <>
      <section>
        <label htmlFor="Name">Name:</label>
          <input type="text" 
                 id="name" 
                 placeholder="Enter name"
                 value={contact.name}
                 onChange={handleChange}
          />
      </section>
      <section>
        <label htmlFor="Email">Email:</label>
        <input type="email" 
               id="email" 
               placeholder="Enter Email"
               value={contact.email}
                onChange={handleChange}
        />
      </section>
      <section>
        <label htmlFor="PhoneNo">Phone No:</label>
        <input type="number" 
               id="phone" 
               placeholder="Enter Phone No"
               value={contact.phone}
                onChange={handleChange}
        />
      </section>
      <section>
        <button onClick={addContact}>Add</button>
      </section>
    </>
  );
}
export default ContactForm