function ContactItem(props) {
  return (
    <>
    <h1>Detail Selected Contact List is</h1>
    <div>
     <h3>Name is {props.viewContact.name} </h3>
     <h3>Email is {props.viewContact.email} </h3>
     <h3>Phone No is {props.viewContact.phone} </h3>
    </div>
    </>
    )
}
export default ContactItem