function ContactList(props) {
    let { contacts } = props;
    let deleteContact = props.deleteContact
    let onEdit = props.onEdit
    let viewContact = props.onView
  return (
    <>
    <h2>Contacts  List</h2>

    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
        </tr>
      </thead>
      <tbody>
        {contacts.map((display,index) => (
            <tr key={index}>
                <td>{display.name}</td>
                <td>{display.email}</td>
                <td>{display.phone}</td>
                <td>
                    <button onClick={()=>viewContact(index)}>View</button>
                    <button onClick={()=>onEdit(index)}>Edit</button>
                    <button onClick={() => deleteContact(index)}>Delete</button>
                </td>
            </tr>
        ))}
      </tbody>
    </table>
    </>
  );
}
export default ContactList