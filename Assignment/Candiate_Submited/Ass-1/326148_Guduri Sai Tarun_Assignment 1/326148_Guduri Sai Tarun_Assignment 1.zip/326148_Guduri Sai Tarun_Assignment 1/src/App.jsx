import { useState, useEffect } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ContactForm from "./Components/ContactForm";
import ContactList from "./Components/ContactList";
import ContactItem from "./Components/ContactItem";
import Swal from "sweetalert2";

function App() {
   //state1 for field change.
  let [details, setDetails] = useState({
    name: "",
    email: "",
    phoneNumber: ""
  });

    //state2 for maintaining list.
  let [lists,setList] = useState([]);

  //state3 for edit/update.
  let [editIndex, setEditIndex] = useState(null);

    // state4 for showing details in ContactItem
  let [showList, setShowList] = useState(null);

  //add the record
  let add = () => {
    if (!details.name || !details.email || !details.phoneNumber) {
        Swal.fire({
          title: "Missing Fields",
          text: "Please fill in all fields.",
          icon: "warning",
          timer: 4000,
        });
        return;
    }
    if (editIndex !== null) {
      // To update existing contact
      let updatedList = [...lists];
      updatedList[editIndex] = details;
      setList(updatedList);
      setEditIndex(null);
    } else {
      // To add new contact
      setList([...lists, details]);
    }
    setDetails({ name: "", email: "", phoneNumber: "" });
 };

 // Handler for update button
let handleUpdate = (list, index) => {
  setDetails(list);
  setEditIndex(index);
};

let showDetails = (list) => {
  setShowList(list);
};

useEffect(() => {
    if (showList) {
      const timer = setTimeout(() => setShowList(null), 20000); 
      return () => clearTimeout(timer);
    }
  }, [showList]);
  
return (
    <>
      <ContactForm
        details={details}
        setDetails={setDetails}
        add={add}
      />
      {lists.length > 0 && <ContactList
        lists={[lists,setList]} 
        upd={handleUpdate} 
        item={showDetails}
        />}
        {(
          <ContactItem list={showList}/>
        )}
    </>
  );
}

export default App
