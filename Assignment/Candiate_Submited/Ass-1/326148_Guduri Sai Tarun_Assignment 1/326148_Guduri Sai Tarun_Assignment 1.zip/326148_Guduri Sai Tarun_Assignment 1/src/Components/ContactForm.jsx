import { useState } from "react";

function ContactForm(props) {
 let { details, setDetails, add} = props;

 let change = (event) => {
    let { id, value } = event.target;
    setDetails(details => ({
      ...details,
      [id]: value
    }));
  };

  return (
        <>
         <section>
           <label htmlFor="name">Name : </label>
           <input
            type="text"
            id="name"
            placeholder="Enter name"
            value={details.name}
            onChange={change}
            />
         </section>
         <section>
           <label htmlFor="email">Email : </label>
           <input
            type="text"
            id="email"
            placeholder="Enter email"
            value={details.email}
            onChange={change}
            />
         </section>
         <section>
           <label htmlFor="phoneNumber">Phone Number : </label>
           <input
            type="text"
            id="phoneNumber"
            placeholder="Enter phnno"
            value={details.phoneNumber}
            onChange={change}
            />
         </section>
         <section>
            <button type="button" onClick={add}>
                Insert/Update
             </button>
         </section>
        </>
  )
}


export default ContactForm;