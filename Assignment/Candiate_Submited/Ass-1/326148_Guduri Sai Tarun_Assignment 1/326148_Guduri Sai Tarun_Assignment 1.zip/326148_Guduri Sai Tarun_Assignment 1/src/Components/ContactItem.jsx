function ContactItem(props) {
  if (!props.list) return null;

  return (
    <>
    <h2>Detail of Selected Contact via ContactItemButton</h2>
    <div>
      <p>`Name is {props.list.name}, Email is {props.list.email}, and
         Phone Number is {props.list.phoneNumber}`</p>
    </div>
    </>
  );
}

export default ContactItem;