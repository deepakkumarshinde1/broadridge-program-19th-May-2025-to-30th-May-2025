function ContactList(props){
  let [lists,setList] = props.lists;
  let upd = props.upd;
  let item = props.item;
  //let item = props.item;


   //remove the record - for a change written it here intead of passing as props
  let del = (index) => {
    let newArray = [...lists];
    newArray.splice(index, 1);
    setList(newArray);
  };
  
  return   (       
    <>
        <h2>Contact List</h2> 
        <h3>Records found: {lists.length}</h3>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>PhoneNumber</th>
            </tr>
          </thead>
          <tbody>
            {lists.map((list, index) => (
              <tr key={index}>
                <td>{list.name}</td>
                <td>{list.email}</td>
                <td>{list.phoneNumber}</td>
                <td>
                  <button onClick={() => upd(list,index)}>Update</button>
                  <button onClick={() => del(index)}>Delete</button>
                  <button onClick={() => item(list)}>ContactItem</button>
                </td>
              </tr>
            ))}
          </tbody>
         </table>
     </>
             )
}

export default ContactList;