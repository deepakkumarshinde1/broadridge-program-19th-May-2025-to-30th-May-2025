import { useState } from "react";
import "./App.css";
import ContactList from "./components/ContactListItems";
import ContactForm from "./components/ContactUIForm";

function App() {
  let [contactsDetails, setContactsDetails] = useState([]);
  let [editFlowFlag, seteditFlowFlag] = useState(false);
  let [editFlowIndex, seteditFlowIndex] = useState(null);
  let [ContactFormData, setContactFormData] = useState({
    name: "",
    email: "",
    phoneNumber: "",
  });
  let addUpdateContactData = (contact) => {
    if (editFlowFlag) {
      let ContactCopy = [...contactsDetails];
      ContactCopy.splice(editFlowIndex, 1, contact);
      setContactsDetails(ContactCopy);
      seteditFlowFlag(!editFlowFlag);
    } else {
      setContactsDetails([...contactsDetails, contact]);
    }
  };
  let editHandler = (contact, index) => {
    seteditFlowFlag(true);
    setContactFormData(contact);
    seteditFlowIndex(index);
  };
  let deleteHandler = (phoneNumber) => {  //For deleting we need uniq number so selected here phonenumber
    let getContactDetails = contactsDetails.filter(
      (contact) => contact.phoneNumber !== phoneNumber
    );
    setContactsDetails(getContactDetails);
  };
  return (
    <>
      <div className="App">
        <h3>Contact Management App</h3>
        <ContactForm
          submitFormData={addUpdateContactData}
          setContactFormData={setContactFormData}
          ContactFormData={ContactFormData}
          editFlowFlag={editFlowFlag}
        />
        <ContactList
          contacts={contactsDetails}
          editHandler={editHandler}
          deleteHandler={deleteHandler}
        />
      </div>
    </>
  );
}

export default App;
