function ContactItem({ contact, editHandler, deleteHandler, index }) {
  return (
    <>
      <tr>
        <td>{contact.name}</td>
        <td>{contact.email}</td>
        <td>{contact.phoneNumber}</td>
        <td>
          <button onClick={() => editHandler(contact, index)}>Edit</button>
          <button onClick={() => deleteHandler(contact.phoneNumber)}>Delete</button>
        </td>
      </tr>
    </>
  );
}


export default ContactItem;
