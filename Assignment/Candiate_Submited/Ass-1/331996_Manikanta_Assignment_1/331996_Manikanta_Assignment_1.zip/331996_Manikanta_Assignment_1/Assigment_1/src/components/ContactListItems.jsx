import ContactItem from "./ContactItem";

function ContactList({ contacts, editHandler, deleteHandler }) {
  return (
    <>
      <table border={1}>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>PhoneNumber</th>
            <th>Action</th>
          </tr>
          {contacts.length > 0
            ? contacts.map((value, index) => (
                <ContactItem
                  key={value.email}
                  index={index}
                  contact={value}
                  editHandler={editHandler}
                  deleteHandler={deleteHandler}
                />
              ))
            : ""}
      </table>
    </>
  );
}

export default ContactList;
