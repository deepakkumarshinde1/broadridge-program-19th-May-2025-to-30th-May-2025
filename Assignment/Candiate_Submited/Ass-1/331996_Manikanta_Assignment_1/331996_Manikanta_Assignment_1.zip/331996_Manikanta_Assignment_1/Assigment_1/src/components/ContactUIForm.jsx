
function ContactForm({
  submitFormData,
  setContactFormData,
  ContactFormData,
  editFlowFlag,
}) {
  let inputChangeHandler = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    setContactFormData({ ...ContactFormData, [name]: value });
  };

  let handleSubmit = (event) => {
    event.preventDefault();

    submitFormData(ContactFormData);
    setContactFormData({
      name: "",
      email: "",
      phoneNumber: "",
    });
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
         <table>
          <tr>
            <th><label>Name:</label></th> 
            <td> <input name="name" value={ContactFormData.name} onChange={inputChangeHandler}/> </td>
          </tr>        
          <tr>
            <th> <label>Email:</label></th>
            <td><input name="email"  value={ContactFormData.email} onChange={inputChangeHandler} /></td>
          </tr>
          <tr>
            <th><label>PhoneNumner:</label></th>
            <td><input name="phoneNumber" value={ContactFormData.phoneNumber} onChange={inputChangeHandler} /></td>
          </tr>
          <tr>
            <th style={{ textAlign: 'right'}}><button type="submit">{editFlowFlag ? "Update" : "Add"} </button></th>
          </tr>
          </table>
      </form>
    </>
  );
}

export default ContactForm;
