import { useState } from "react"; //use state is a react hook that allows us to add state to functional components
import "./App.css";
import ContactForm from "./components/ContactForm"; // contact form is a component that allows us to add and update contacts
import ContactList from "./components/ContactList"; // contact list is a component that displays the list of contacts
import Container from "react-bootstrap/Container"; // container is a bootstrap component that provides a responsive fixed width container
import Row from "react-bootstrap/Row"; // row is a bootstrap component that creates a row in the grid system
import Col from "react-bootstrap/Col"; // col is a bootstrap component that creates a column in the grid system
import "bootstrap/dist/css/bootstrap.min.css"; // bootstrap is a CSS framework that provides pre-defined styles for components

function App() {
  // App is the main component of the application
  let [contactsDetails, setContactsDetails] = useState([]); // contactsDetails is a state variable that stores the list of contacts
  let [editFlowFlag, seteditFlowFlag] = useState(false); // editFlowFlag is a state variable that indicates whether the user is in edit mode or not
  let [editFlowIndex, seteditFlowIndex] = useState(null); // editFlowIndex is a state variable that stores the index of the contact being edited
  let [ContactFormData, setContactFormData] = useState({
    name: "",
    email: "",
    phNumber: "",
  }); // ContactFormData is a state variable that stores the data entered in the contact form

  // addUpdateContactData is a function that adds or updates a contact in the list
  let addUpdateContactData = (contact) => {
    if (editFlowFlag) {
      let ContactCopy = [...contactsDetails];
      ContactCopy.splice(editFlowIndex, 1, contact);
      setContactsDetails(ContactCopy); // update the contact list with the updated contact
      seteditFlowFlag(!editFlowFlag); // toggle the editFlowFlag to false
    } else {
      setContactsDetails([...contactsDetails, contact]); // add the new contact to the list
    }
  };

  // deleteHandler is a function that deletes a contact from the list
  let deleteHandler = (contactEmail) => {
    let getContactDetails = contactsDetails.filter(
      (contact) => contact.email !== contactEmail
    );
    setContactsDetails(getContactDetails); // update the contact list with the remaining contacts
  };

  // editHandler is a function that sets the contact data in the form for editing
  let editHandler = (contact, index) => {
    seteditFlowFlag(true); // set the editFlowFlag to true
    setContactFormData(contact); // set the contact data in the form for editing
    seteditFlowIndex(index); // set the index of the contact being edited
  };
  return (
    <>
      <div className="App">
        <h3 style={{ color: "#ff0100a1", textAlign: "center" }}>
          Contact Management App
        </h3>
        <Container>
          <Row>
            <Col></Col>
            <Col xs={6}>
              <ContactForm
                submitFormData={addUpdateContactData}
                setContactFormData={setContactFormData}
                ContactFormData={ContactFormData}
                editFlowFlag={editFlowFlag}
              />
            </Col>
            <Col></Col>
          </Row>
          <Row>
            <Col></Col>
            <Col xs={10}>
              <ContactList
                contacts={contactsDetails}
                editHandler={editHandler}
                deleteHandler={deleteHandler}
              />
            </Col>
            <Col></Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default App;
