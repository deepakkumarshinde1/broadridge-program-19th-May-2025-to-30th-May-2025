import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

function ContactForm({
  submitFormData, // function to submit the form data
  setContactFormData, // function to set the contact form data
  ContactFormData, // object containing the contact form data
  editFlowFlag, // boolean flag to indicate if the form is in edit mode
}) {
  // inputChangeHandler is a function to handle input changes
  let inputChangeHandler = (event) => {
    let name = event.target.name; // event.target.name gets the name of the input field
    let value = event.target.value; // event.target.value gets the value of the input field
    setContactFormData({ ...ContactFormData, [name]: value }); // setContactFormData updates the contact form data with the new value
  };

  // handleSubmit is a function to handle form submission
  let handleSubmit = (event) => {
    event.preventDefault();

    submitFormData(ContactFormData); // submitFormData submits the contact form data
    setContactFormData({
      name: "",
      email: "",
      phNumber: "",
    }); // reset the contact form data
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <Container>
          <Row>
            <Col sm={4}>
              <label htmlFor="name">User Name</label>
            </Col>
            <Col sm={8}>
              <input
                type="text"
                name="name"
                value={ContactFormData.name}
                onChange={inputChangeHandler}
                required
              />
            </Col>
          </Row>
          <Row>
            <Col sm={4}>
              <label htmlFor="email">Email Address</label>
            </Col>
            <Col sm={8}>
              <input
                type="email"
                name="email"
                value={ContactFormData.email}
                onChange={inputChangeHandler}
                required
              />
            </Col>
          </Row>
          <Row>
            <Col sm={4}>
              <label htmlFor="email">Phone Number</label>
            </Col>
            <Col sm={8}>
              <input
                type="number"
                name="phNumber"
                value={ContactFormData.phNumber}
                onChange={inputChangeHandler}
                required
              />
            </Col>
          </Row>
          <button type="submit" className="btn btn-primary">
            {editFlowFlag ? "Update User" : "Add User"}
          </button>
        </Container>
      </form>
    </>
  );
}

export default ContactForm;
