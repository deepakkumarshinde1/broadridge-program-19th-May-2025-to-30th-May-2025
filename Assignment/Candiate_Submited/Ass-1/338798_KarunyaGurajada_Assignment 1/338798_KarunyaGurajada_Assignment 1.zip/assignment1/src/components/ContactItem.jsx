function ContactItem({ contact, editHandler, deleteHandler, index }) {
  return (
    <>
      <tr>
        <td>{contact.name}</td>
        <td>{contact.email}</td>
        <td>{contact.phNumber}</td>
        <td>
          <button className="btn btn-primary" onClick={() => editHandler(contact, index)} style={{marginRight:"10px"}}>Edit</button>
          <button className="btn btn-primary" onClick={() => deleteHandler(contact.email)}>Delete</button>
        </td>
      </tr>
    </>
  );
}

export default ContactItem;
