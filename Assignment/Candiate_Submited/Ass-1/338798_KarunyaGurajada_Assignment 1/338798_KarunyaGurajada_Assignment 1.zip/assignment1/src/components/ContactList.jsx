import ContactItem from "./ContactItem"; // ContactItem is a component that displays individual contact details

function ContactList({ contacts, editHandler, deleteHandler }) {
  return (
    <>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {contacts.length > 0 ? (
            contacts.map((value, index) => (
              <ContactItem
                key={value.email}
                index={index}
                contact={value}
                editHandler={editHandler}
                deleteHandler={deleteHandler}
              />
            ))
          ) : (
            <tr>
              <td colSpan={4} style={{ textAlign: "center" }}>
                No UserData yet
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </>
  );
}

export default ContactList;
