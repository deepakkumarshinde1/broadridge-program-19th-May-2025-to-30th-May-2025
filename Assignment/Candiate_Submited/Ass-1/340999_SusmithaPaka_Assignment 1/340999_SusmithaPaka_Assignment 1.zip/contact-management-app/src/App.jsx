import { useState } from "react";
import "./App.css";
import ContactForm from "./components/ContactForm";
import ContactList from "./components/ContactList";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  let [contactDetails, setContactDetails] = useState([]); // state setting for contact details
  let [editFlag, setEditFlag] = useState(false); // state setting for edit flag
  let [editIndex, setEditIndex] = useState(null); // state setting for edit index
  let [contactData, setContact] = useState({
    name: "",
    email: "",
    phoneNumber: "",
  });

// Function to add or update based on edit flag
  let addOrUpdateContact = (contact) => {
    if (editFlag) {
      let contactDetailsCopy = [...contactDetails]; //creating a shallow copy using spread operator inorder to maintain the latest.
      contactDetailsCopy.splice(editIndex, 1, contact); //using splice to replace the contact.
      setContactDetails(contactDetailsCopy); // update contactDetails state with updated array list
      setEditFlag(!editFlag); //setting edit flag to false as editing is completed.
    } else {
      setContactDetails([...contactDetails, contact]); //while adding, the new contact will be added at end.
    }
  };

//Function to delete the contact
  let deleteRecord = (index) => {
    let newContactDetails = [...contactDetails] //creating copy to maintain latest
    newContactDetails.splice(index,1); // using splice to remove contact at specified index.
    setContactDetails(newContactDetails);// to update the contact list with updated values after deletion
  };

//Function to trigger on edit click for specific index
  let editRecord = (contact, index) => {
    setEditFlag(true); //setting editFlag to true
    setContact(contact); //setting contact for the form to pre-fill with selected contact
    setEditIndex(index);// To stor index to update the row easily.
  };

  return (
    <>    
    <Container>
    <h3 className="heading">Contact Management App</h3>
      <Row className="table-row">
        <Col xs={6}>
        <ContactForm
          submitFormData={addOrUpdateContact}
          setContact={setContact}
          contactData={contactData}
          editFlag={editFlag}
        /></Col>
        <Col></Col>
      </Row>
      {contactDetails.length > 0 && <Row>
        <Col xs={12}>
        <ContactList
          contacts={contactDetails}
          editRecord={editRecord}
          deleteRecord={deleteRecord}
        /></Col>
        <Col></Col>
      </Row>}
    </Container>
    </>
  );
}

export default App;
