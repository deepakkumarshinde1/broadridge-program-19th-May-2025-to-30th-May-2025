import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function ContactForm({
  submitFormData,
  setContact,
  contactData,
  editFlag,
}) {

  //To handle input changes
  let inputChangeHandler = (event) => {
    let name = event.target.name; // To get the changed name of input.
    let value = event.target.value; // To get the changed value of input.
    setContact({ ...contactData, [name]: value });
  };

  let handleSubmit = (event) => {
    event.preventDefault();

    submitFormData(contactData);
    setContact({
      name: "",
      email: "",
      phoneNumber: "",
    });
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
      <Row className='table-row'>
        <Col sm={6}>
        <label htmlFor="name">Name:</label>
        </Col>
        <Col sm={6}>
        <input type="text"
          name="name"
          value={contactData.name}
          onChange={inputChangeHandler} 
          required
        />
        </Col>
      </Row>

      <Row className='table-row'>
        <Col sm={6}>
        <label htmlFor="email">Email:</label>
        </Col>
        <Col sm={6}>
        <input type="email"
          name="email"
          value={contactData.email}
          onChange={inputChangeHandler}
          required
        />
        </Col>
      </Row>

      <Row className='table-row'>
        <Col sm={6}>
        <label htmlFor="email">Phone Number:</label>
        </Col>
        <Col sm={6}>
        <input type="number"
          name="phoneNumber"
          value={contactData.phoneNumber}
          onChange={inputChangeHandler}
          required
        />
        </Col>
      </Row>
        <button className="btn btn-dark table-row" type="submit">{editFlag ? "Update" : "Add"} </button>
      </form>
    </>
  );
}

export default ContactForm;

