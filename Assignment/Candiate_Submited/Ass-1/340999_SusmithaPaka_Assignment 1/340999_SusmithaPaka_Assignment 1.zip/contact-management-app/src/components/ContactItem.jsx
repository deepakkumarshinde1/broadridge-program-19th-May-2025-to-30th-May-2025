function ContactItem({ contact, editRecord, deleteRecord, index }) {
  return (
    <>
      <tr>
        <td>{contact.name}</td>
        <td>{contact.email}</td>
        <td>{contact.phoneNumber}</td>
        <td>
          <button className="btn btn-dark action-btn" onClick={() => editRecord(contact, index)}>Edit</button>
          <button className="btn btn-dark action-btn" onClick={() => deleteRecord(index)}>Delete</button>
        </td>
      </tr>
    </>
  );
}

export default ContactItem;
