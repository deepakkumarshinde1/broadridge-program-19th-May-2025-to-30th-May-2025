import ContactItem from "./ContactItem";

function ContactList({ contacts, editRecord, deleteRecord }) {
  return (
    <>
      <table class="table table-striped">
        <thead>
          <h3>Contact List</h3>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Action Buttons</th>
          </tr>
        </thead>
        <tbody>
          {contacts && 
            contacts.map((value, index) => (
                <ContactItem
                  key={index}
                  index={index}
                  contact={value}
                  editRecord={editRecord}
                  deleteRecord={deleteRecord}
                />
              ))
          }
        </tbody>
      </table>
    </>
  );
}

export default ContactList;
