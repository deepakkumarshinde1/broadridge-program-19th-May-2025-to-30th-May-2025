import { useState } from "react";
import ContactForm from './components/ContactForm';
import ContactList from './components/ContactList';
import ContactItem from './components/ContactItem';
import './App.css';

function App() {
 
    let [contacts,setContacts] = useState(null);
    let [name,setName] = useState();
    let [email,setEmail] = useState();
    let [phoneNumber,setPhoneNumber] = useState();
    let [editIndex,setEditIndex] = useState(null);
    let [contactItem,setContactItem] = useState(null);

    let saveContact = () => {
        let arrayContacts = contacts ? [...contacts] : [];
        if(editIndex == null)
        {
            arrayContacts.push({Name: name, Email: email, PhoneNumber: phoneNumber});
        }
        else
        {
            arrayContacts[editIndex] = {Name: name, Email: email, PhoneNumber: phoneNumber}
            setEditIndex(null);
        }
        setContacts(arrayContacts);
        resetContact();
        setContactItem(null);
    }

    let viewContact = (contact) => {
        setContactItem(contact);
    }

    let editContact = (contact, index) => {
        setName(contact.Name);
        setEmail(contact.Email);
        setPhoneNumber(contact.PhoneNumber);
        setEditIndex(index);
        setContactItem(null);
    }

    let deleteContact = (index) => {
        let arrayContacts = [...contacts];
        arrayContacts.splice(index, 1);
        if(arrayContacts.length == 0)
            setContacts(null);
        else
            setContacts(arrayContacts);
       resetContact();
       setContactItem(null);
    }

    let resetContact = () => {
        setName("");
        setEmail("");
        setPhoneNumber("");
        setEditIndex(null);
    }

    let handleName = (event) => {
        setName(event.target.value);
    }

    let handleEmail = (event) => {
        setEmail(event.target.value);
    }

    let handlePhoneNumber = (event) => {
        setPhoneNumber(event.target.value);
    }

  return (
    <>
      <h1 className="contact-form-section">Contact Management Tool</h1>
      <div>
       <ContactForm name={name} email={email} phoneNumber={phoneNumber} handleName={handleName} handleEmail={handleEmail} handlePhoneNumber={handlePhoneNumber} saveContact={saveContact} editIndex={editIndex}/>
      </div>
      <div>
         {contacts && <ContactList contacts={contacts} viewContact={viewContact} editContact={editContact} deleteContact={deleteContact}/>}
      </div>
      <div>
         {contactItem && <ContactItem contactItem={contactItem} />} 
      </div>
    </>
  )
}

export default App
