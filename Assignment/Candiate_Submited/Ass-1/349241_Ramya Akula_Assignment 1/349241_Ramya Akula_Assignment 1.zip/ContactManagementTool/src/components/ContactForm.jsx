import './ContactForm.css'

function ContactForm(props) {
    let {name, email, phoneNumber, handleName, handleEmail, handlePhoneNumber, saveContact, editIndex} = props;
    return [
       <section className="contact-form-section">
            <div>
                <h2>Fill Contact</h2>
                <label htmlFor="name">Name </label>
                <input id="name" type="text" value={name} onChange={handleName}></input>
                <br/>
                <label htmlFor="email">Email </label>
                <input id="email" type="email" value={email} onChange={handleEmail}></input>
                <br/>
                <label htmlFor="phoneNumber">Phone Number </label>
                <input id="phoneNumber" type="number" value={phoneNumber} onChange={handlePhoneNumber}></input>
                <br/>
                <button onClick={saveContact}>{editIndex !== null ? "Update" : "Add"}</button>
            </div>
        </section>
    ];
}

export default ContactForm