import './ContactItem.css'

export default function ContactItem(props) {
    let {contactItem} = props;

    return [
        <div className="contact-item-info">
           <h2>Contact Information</h2>
            <p><b>Name:</b> {contactItem.Name}</p>
            <p><b>Email:</b> {contactItem.Email}</p>
            <p><b>Phone Number:</b> {contactItem.PhoneNumber}</p>
        </div>
    ];
}

