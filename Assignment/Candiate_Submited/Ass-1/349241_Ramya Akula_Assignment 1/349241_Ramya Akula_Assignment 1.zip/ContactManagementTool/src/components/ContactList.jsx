import './ContactList.css'

function ContactList(props) {
    let {contacts, viewContact, editContact, deleteContact} = props;
    return [
        <div className="contact-list-container">
            <h2>Contact Details</h2>
            <table>
               <thead>
                <tr>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Phone Number</td>
                    <td>Action</td>
                </tr>
                </thead>
               <tbody>  
                {contacts.map((contact, index) => (
                    <tr key={index}>
                        <td>{contact.Name}</td>
                        <td>{contact.Email}</td>
                        <td>{contact.PhoneNumber}</td>
                        <td>
                            <button onClick={() => viewContact(contact)}>View</button>
                            <button onClick={() => editContact(contact, index)}>Edit</button>
                            <button onClick={() => deleteContact(index)}>Delete</button>
                        </td>
                    </tr>
                ))}
            </tbody>
            </table>
      </div>
    ];
}


export default ContactList