import { useState } from 'react'
import ContactDetailsForm from './components/ContactDetailsForm';
import ContactDetailsListing from './components/ContactDetailsListing';

import './App.css'

function App() {
const [contacts, setContacts] = useState([]);
const [editingContact, setEditingContact] = useState(null);
const [editingIndex, setEditingIndex] = useState(null);

// add the contact details to the state variable
const addContact = (contact) => {
    setContacts([...contacts, contact]);
  };

// updates the Contact info
const updateContact = (updatedContact) => {
    const updatedContacts  = [...contacts];
    updatedContacts[editingIndex] = updatedContact;
    setContacts(updatedContacts);
    setEditingContact(null);
    setEditingIndex(null);
  };
// edit the Contact info
  const editContact = (contact, index) => {
    setEditingContact(contact);
    setEditingIndex(index);
  };
// delete the Contact info
   const deleteContact = (index) => {
    const newContacts = [...contacts];
    newContacts.splice(index, 1);
    setContacts(newContacts);

    if (editingIndex === index) {
      setEditingContact(null);
      setEditingIndex(null);
    }
    };

  return (
    <div>
      <h1>Contact Management App</h1>
      <ContactDetailsForm add={addContact} update={updateContact} editingContact={editingContact}/>
      <ContactDetailsListing showcontacts={contacts} onEdit={editContact} onDelete={deleteContact}/>
    </div>
  )
}

export default App
