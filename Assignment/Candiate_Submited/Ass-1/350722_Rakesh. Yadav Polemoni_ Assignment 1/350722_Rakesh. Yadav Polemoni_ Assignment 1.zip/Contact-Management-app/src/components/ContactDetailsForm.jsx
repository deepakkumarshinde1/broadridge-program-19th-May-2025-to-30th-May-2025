import React, { useState, useEffect } from 'react';

function ContactDetailsForm({add, update, editingContact}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
 
  // triggers when the user input got chnages
useEffect(() => {
    if (editingContact) {
      setName(editingContact.name);
      setEmail(editingContact.email);
      setMobile(editingContact.mobile);
    } else {
      setName('');
      setEmail('');
      setMobile('');
    }
  }, [editingContact]);
  
  // triggers when the user hit the submit button
  const handleSubmit = (e) => {
    //e.preventDefault();
    
if (!name || !email || !mobile) return;
const contact = { name, email, mobile };

    if (editingContact) {
      update(contact);
    } else {
      add(contact);
    }

    setName('');
    setEmail('');
    setMobile('');

  };

  return (
    // input form for Userinputs
    <form onSubmit={handleSubmit} className="contact-form">
      <input 
        type="text" 
        placeholder="Enter Name" 
        value={name}
        onChange={(e) => setName(e.target.value)} 
      />
      <input 
        type="text" 
        placeholder="Enter Email" 
        value={email}
        onChange={(e) => setEmail(e.target.value)} 
      />
       <input
        type="text" 
        placeholder="Enter Mobile Number" 
        value={mobile}
        onChange={(e) => setMobile(e.target.value)} 
      />
      <button type="submit">{editingContact ? 'Update Contact' : 'Add Contact'}</button> 
    </form> 
  );
}

export default ContactDetailsForm;
