function ContactDetailsListing({showcontacts, onEdit, onDelete}){
    return (
        <div className="contacts-list">
            <h2>Contacts</h2>
            <table className="contacts-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {showcontacts.map((contact, index) => (
                        <tr key={index}>
                            <td>{contact.name}</td>
                            <td>{contact.email}</td>
                            <td>{contact.mobile}</td>
                            <td className="action-buttons">
                                <button 
                                    onClick={() => onEdit(contact,index)} //redirects to use the editContact
                                    className="update-btn"
                                >
                                    Edit
                                </button>
                                <button 
                                    onClick={() => onDelete(index)} //redirects to use the deleteContact
                                    className="delete-btn"
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default ContactDetailsListing