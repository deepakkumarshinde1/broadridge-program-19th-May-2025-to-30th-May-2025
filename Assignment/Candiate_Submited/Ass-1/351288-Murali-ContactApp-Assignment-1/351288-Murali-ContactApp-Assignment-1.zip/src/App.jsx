import ContactForm from "./components/ContactForm";
import ContactList from "./components/ContactList";
import { useEffect, useState } from "react";

function App() {
  const [contact, setContact] = useState({ "name": "", "email": "", "contact": "" }) //collects form data entered by user
  const [contactList, setContactList] = useState([]);                                //contains all contacts
  const [updateFlag, setUpdateFlag] = useState(false);                                //identify the operation so we can perform edit or add logic
  const [editItemIndex, seteditItemIndex] = useState(null);


  //captures the user entered data
  function handleChange(e) {
    const { name, value } = e.target;
    setContact(
      {
        ...contact, [name]: value
      }
    );
  }

  //updates the list of contacts when new entry added
  function handleSubmit(e) {
    e.preventDefault();
    if (updateFlag) {
      setContactList(prevList => [...prevList.slice(0, editItemIndex), contact, ...prevList.slice(editItemIndex + 1)]);
      setUpdateFlag(false);
    }
    else {
      setContactList([...contactList, contact]);
    }
    setContact({ "name": "", "email": "", "contact": "" });

  }

  //when user clicks on edit button this will handle
  function handleEditclick(index) {
    setUpdateFlag(true);
    const editContact = contactList[index];
    seteditItemIndex(index);
    setContact({ ...editContact });

  }

  //handel the delete operation
  function handleDelete(index) {
    setContactList((prevList) => prevList.filter((_, i) => i !== index))

  }

  return (
    <div>
      <div className="container text-center">
        <h2 className="center">Contact Management App</h2>
      </div>
      <div className="container mt-4">
        <div className="row">
          <div className="col-md-7">
            <ContactForm
              handleSubmit={handleSubmit}
              handleChange={handleChange}
              contact={contact}
              updateFlag={updateFlag}
            />
          </div>
          <div className="col-md-5">
            <ContactList
              contactList={contactList}
              handleEditclick={handleEditclick}
              handleDelete={handleDelete}
              editItemIndex={editItemIndex}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default App;
