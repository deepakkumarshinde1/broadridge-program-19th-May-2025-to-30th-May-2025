function ContactForm(props) {
    const { handleChange, handleSubmit, contact, updateFlag } = props;
    return (
        <>
            <div className="container mt-5">
                <h2 className="mb-4">Contact Form</h2>
                <div className="row">
                    <div className="col-md-6">
                        <form onSubmit={handleSubmit} className="row g-3">
                            <div className="col-12 d-flex align-items-center">
                                <label htmlFor="name" className="form-label me-2 mb-0" style={{ width: "100px" }}>Name:</label>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    value={contact.name}
                                    placeholder="Enter your name"
                                    onChange={handleChange}
                                    className="form-control"
                                />
                            </div>
                            <div className="col-12 d-flex align-items-center">
                                <label htmlFor="email" className="form-label me-2 mb-0" style={{ width: "100px" }}>Email:</label>
                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    value={contact.email}
                                    placeholder="Enter your email"
                                    onChange={handleChange}
                                    className="form-control"
                                />
                            </div>
                            <div className="col-12 d-flex align-items-center">
                                <label htmlFor="contact" className="form-label me-2 mb-0" style={{ width: "100px" }}>Contact:</label>
                                <input
                                    type="number"
                                    id="contact"
                                    name="contact"
                                    value={contact.contact}
                                    placeholder="Enter your contact number"
                                    onChange={handleChange}
                                    className="form-control"
                                />
                            </div>
                            <div className="col-12 mt-3">
                                <button type="submit" className="btn btn-primary px-4">
                                    {updateFlag ? "Update" : "Add"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ContactForm;