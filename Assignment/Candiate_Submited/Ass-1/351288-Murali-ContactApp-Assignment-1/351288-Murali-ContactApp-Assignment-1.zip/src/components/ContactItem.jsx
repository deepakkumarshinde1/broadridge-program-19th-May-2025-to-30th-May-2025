
function Contactitem(props) {
    const { contactItem, index, handleEditclick, handleDelete, editItemIndex} = props;
    return (
        <>
            <tbody>
                <tr className={editItemIndex==index?"bg-warning":""}>   {/* modifies the bg color when user performs edit operation */}
                    <td>{index}</td>
                    <td>{contactItem.name}</td>
                    <td>{contactItem.email}</td>
                    <td>{contactItem.contact}</td>
                    <td>
                        <button onClick={() => handleEditclick(index)} className="btn btn-primary btn-sm me-2">Edit</button>
                        <button onClick={() => handleDelete(index)} className="btn btn-danger btn-sm">Delete</button>
                    </td>
                </tr>
            </tbody>
        </>
    )
};

export default Contactitem;