import Contactitem from "./ContactItem";

function ContactList(props){
    const {contactList,handleEditclick,handleDelete,editItemIndex}=props;
    return(
        <div className="container">
                <h3>Contacts</h3>
                <table className="table table-striped table-hover align-middle">
                    <thead className="table-dark">
                        <tr>
                        <th>S.NO</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone number</th>
                        <th>Actions</th>
                        </tr>
                    </thead>
                    {
                        contactList.length>0?
                        contactList.map(
                            (contactItem,index)=>{
                               return <Contactitem key={index} contactItem={contactItem} index={index} handleEditclick={handleEditclick} handleDelete={handleDelete} editItemIndex={editItemIndex}/>
                            }
                        ):
                        <h5 className="text-center">No Contacts Added!</h5>
                    }
                    </table>
            </div>
    )
}

export default ContactList;