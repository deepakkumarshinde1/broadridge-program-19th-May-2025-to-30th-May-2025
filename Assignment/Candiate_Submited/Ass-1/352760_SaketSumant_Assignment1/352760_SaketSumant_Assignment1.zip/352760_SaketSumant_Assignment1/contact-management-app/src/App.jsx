import { useState } from 'react';
import ContactForm from './components/ContactForm';
import ContactList from './components/ContactList';

function App() {
  const [contactData, setContactData] = useState({ name: '', email: '', phone: '' });
  const [contact, setContact] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  function handleChange(event) {
    // method to handle any updates
    console.log(event);
    const { name, value } = event.target;
    setContactData({ ...contactData, [name]: value });
  }

  function handleSave(event) {
    // when user chooses to save the data during add or update, this method will trigger
    event.preventDefault();

    if (
      !contactData.name.trim() ||
      !contactData.email.trim() ||
      !contactData.phone.trim()
    ) {
      alert("All fields are required!");
      return;
    }

    if (editIndex !== null) {
      // Update in case of Edit mode
      const updatedContacts = [...contact];
      updatedContacts[editIndex] = contactData;
      setContact(updatedContacts);
      setEditIndex(null); // Reset edit mode
    } else {
      // Only add to the list in Add mode
      setContact([...contact, contactData]);
    }

    // Reset form in both add and edit modes
    setContactData({ name: '', email: '', phone: '' });
  }

  function handleEdit(index) {
    setContactData(contact[index]);
    setEditIndex(index);
  }

  function handleDelete(index) {
    const updatedContacts = contact.filter((_, i) => i !== index);
    setContact(updatedContacts);
    // Reset form in delete mode
    setContactData({ name: '', email: '', phone: '' });
  }

  return (
    <>
      <ContactForm
        contactData={contactData}
        onChange={handleChange}
        onSave={handleSave}
        editMode={editIndex !== null}
      />
      <h2>Contact List</h2>
      {contact.length === 0 && <p>No contacts available</p>}
      {contact.length > 0 && <p>Total Contacts: {contact.length}</p>}
      <br />
      {contact.map((item, index) => (
        <ContactList
          key={index}
          item={item}
          onEdit={() => handleEdit(index)}
          onDelete={() => handleDelete(index)}
        />
      ))}
    </>
  );
}

export default App;