// This is a simple contact form component that allows users to add new contacts.
function ContactForm(props) {
  let { contactData, onChange, onSave, editMode } = props;
  return (
    <>
      
      <form onSubmit={onSave}>
        <h2>{editMode ? "Edit Contact" : "Enter Contact Info" }</h2>
        {/* Header change based on whether add or edit case */}
        <input
          type="text" id="name" name="name" placeholder="Name" required 
          value={contactData.name}
          onChange={onChange}
        /><br />

        <input
          type="email" id="email" name="email" placeholder="Email" required
          value={contactData.email}
          onChange={onChange}
        /><br />

        <input
          type="number" id="phone" name="phone" placeholder="Phone Number" required
          value={contactData.phone}
          onChange={onChange}
        /><br />
        {/*Button name chane based on Add case(Save) or Update case(Update)*/}
        <button type="submit">{editMode ? "Update Contact" : "Save Contact"}</button>
        <br /><br />
      </form>
    </>
  );
}

export default ContactForm;