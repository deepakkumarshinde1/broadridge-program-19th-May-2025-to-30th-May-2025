// This component is responsible to display data in the Contact List
function ContactList(props) {

  let { item, onEdit, onDelete } = props;
  return (
    <div>
      <form>
        <br />
        <fieldset disabled >
          <label>Name</label>
          <input type="text" value={item.name} style={{ marginRight: '16px' }} />

          <label>Email</label>
          <input type="text" value={item.email} style={{ marginRight: '16px' }} />

          <label>Phone Number</label>
          <input type="number" value={item.phone} style={{ marginRight: '16px' }} />
        </fieldset>
      </form>
      <button onClick={onEdit}style={{ marginRight: '16px' }}>Edit</button>
      <button onClick={onDelete}>Delete</button>
      <br />
    </div>
  )
}

export default ContactList;