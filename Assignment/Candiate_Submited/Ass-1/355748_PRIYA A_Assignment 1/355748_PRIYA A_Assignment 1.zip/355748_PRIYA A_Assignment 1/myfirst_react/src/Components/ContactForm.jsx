import { useState } from 'react'
import '../ContactForm.css'

function ContactForm({addContactList}) 
{
  let [name, setName] = useState("");
  let [email, setEmail] = useState("");
  let [mobile, setMobile] = useState("");
  //console.log(addContactList);

  let addContact = (event) => {
    //this prevents page refresh - without this page was getting refreshed
    event.preventDefault();
    if (!name || !email || !mobile) return;
    addContactList({ name, email, mobile });
    //Clear the fields after the contacts state is set
    setName("");
    setEmail("");
    setMobile("");
  };

  return (
    <div className="form-container">
      <form onSubmit={addContact}>
        <input type="text" placeholder="Name" value={name} onChange={(event) => setName(event.target.value)} required />
        <br/><br/>
        <input type="email" placeholder="Email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        <br/><br/>
        <input type="tel" placeholder="Mobile Number" value={mobile} onChange={(event) => setMobile(event.target.value)} required pattern="[0-9]{10}" />
        <br/><br/>
        <button type="submit" className="button-big">Add Contact</button>
      </form>
    </div>
  );
}

export default ContactForm
