function ContactItem ({contact, onClose}) {
    console.log("ContactSelected" + contact);
  return (
    <div style={{ border: "1px solid #646cffaa", padding: "10px", margin: "5px" }}>
      <h3 style={{ color: "#646cffaa", fontStyle: "italic"}}>{contact.name}</h3>
      <p><b>Email:</b> {contact.email}</p>
      <p><b>Mobile:</b> {contact.mobile}</p>
      <button className="button-big" onClick={onClose}>Close</button>
    </div>
  );
};

export default ContactItem;