import { useState } from "react";
import ContactForm from "./ContactForm";
import ContactItem from "./ContactItem";
import '../ContactForm.css'
import Swal from "sweetalert2";

function ContactList() 
{
  let [contacts, setContacts] = useState([]);
  let [editingContact, setEditingContact] = useState(null);
  let [selectedContact, setSelectedContact] = useState(null);
  let [incrementId, setIncrementId] = useState(1);
  
  //add the new contact sent from ContactForm to list of existing contacts
  function addContactList(contact) 
  {
    //check if email already exists to avoid duplicate contacts
    if (contacts.some((contactItem) => contactItem.email === contact.email)) {
        //tried using SweetAlert as highlighted in training
        Swal.fire({
            icon: "error",
            title: "Duplicate Email ID",
            text: "This email is already in use. Please use a different email.",
        });
    return;
    }
    setContacts([...contacts, { id: incrementId, ...contact }]);
    setIncrementId(incrementId + 1);
  }
  //onclick of UpdateContact pass the props to editContact
  let updateContact = (event) =>
  {
    event.preventDefault();
    editContact({
      name: event.target.name.value,
      email: event.target.email.value, 
      mobile: event.target.mobile.value 
    });
  }
  //map and store the necessary states on actual update
  function editContact(updatedContact)
  {
    //if id matches - merged two objects, so that id is merged to updatedContact
    setContacts(contacts.map((contact) => (contact.id === editingContact.id ? { ...contact, ...updatedContact } : contact)));
    setEditingContact(null); //clear editing contact once done
  }
  //tried to remove using specific contactid instead of index
  //so using the contact id tried to find the index and then splice using the index
  let deleteContact = (contactToRemove) => {
    if (window.confirm(`Are you sure you want to delete ${contactToRemove.name}?`)) 
    {
    let recentContact = [...contacts];
    let removingIndex = recentContact.findIndex(contact => contact.id === contactToRemove.id);
    recentContact.splice(removingIndex, 1);
    setContacts(recentContact);
    //Deletion - Confirmation using SweetAlert
    Swal.fire({
      icon: "success",
      title: "Contact Deleted",
      text: `${contactToRemove.name} has been removed successfully!`,
      timer: 3000
  });
}
  };

  return (
    <div>
      {/*pass the addContactList props to ContactForm*/}
      <ContactForm addContactList={addContactList} />
      {/*Contact List with Edit button*/}
      <ul>
        {contacts.map((contact) => (
          <li key={contact.id}>
            <div className="contact-edit-details">
            {/*Tried to use highlight on edit - but to disable the style after sometime it requires lot of effort, will try his using hooks */}
            {/* <div className={`contact-edit-details-text ${contact.isEdited ? "edited-row" : ""}`}>{contact.email}</div> */}
            <div className="contact-edit-details-text">{contact.name} - {contact.email}</div>
            {/*Used inline arrow function and added contact to editingContact state, didn't use separate function*/}
            <button className="button-small" onClick={() => setEditingContact(contact)}>Edit</button>
            <button className="button-small" onClick={() => deleteContact(contact)}>Delete</button>
            <button className="button-small" onClick={() => setSelectedContact(contact)}>View Details</button>
            </div>
          </li>
        ))}
      </ul>

      {/*Edit Form - if there is some contact in editingContact that means there is some item to edit*/}
      {editingContact && (
        <div>
          <h2>Edit Contact</h2>
          <form onSubmit={updateContact}>
            <input className="input-field" type="text" name="name" defaultValue={editingContact.name} required />
            <input className="input-field" type="email" name="email" defaultValue={editingContact.email} required />
            <input className="input-field" type="tel" name="mobile" defaultValue={editingContact.mobile} required pattern="[0-9]{10}" />
            <br/>
            <br/>
            <button className="input-field button-small" type="submit">Update Contact</button>
          </form>
          <br/>
          <button onClick={() => setEditingContact(null)} className ="button-small">Cancel</button>
        </div>
      )}
       {/*Display ContactDetails when ViewDetails button is clicked*/}
       {selectedContact && <ContactItem contact={selectedContact} onClose={() => setSelectedContact(null)}/>}
    </div>
  );
}

export default ContactList;