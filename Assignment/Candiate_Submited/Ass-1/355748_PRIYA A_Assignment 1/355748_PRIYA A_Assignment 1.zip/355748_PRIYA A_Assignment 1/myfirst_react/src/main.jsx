import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import ContactList from './Components/ContactList.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ContactList />
  </StrictMode>
)
