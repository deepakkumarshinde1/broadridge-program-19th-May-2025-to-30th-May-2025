import { useEffect, useState } from 'react'
//import './App.css'
import Header from './components/Header'
import ContactListpage from './components/ContactList'
import Footer from './components/Footer'
import ContactForm from './components/ContactForm';
import ContactItem from './components/ContactItem';


function App() {
 

  const appStyle = {
    width: '100%',
    backgroundColor: 'white', 
    color: 'black' 
  };
    
    let [ContactList, setContactList] = useState([
  {
    "name": "Alice Johnson",
    "email": "alice.johnson@example.com",
    "phonenumber": "+1-555-101-2345"
  },
  {
    "name": "Bob Smith",
    "email": "bob.smith@example.com",
    "phonenumber": "+1-555-102-3456"
  },
  {
    "name": "Charlie Davis",
    "email": "charlie.davis@example.com",
    "phonenumber": "+1-555-103-4567"
  }
   
]);
     let [selectedContact, setSelectedContact] = useState(null);

     let [viewClientDetails, setviewClientDetails] = useState(null);

   const addClient = (client) => {
    setContactList([...ContactList, { ...client}]);
  };

  const deleteClient = (name) => {
    setContactList(ContactList.filter(client => client.name !== name));
  };

  const updateClient = (updatedClient) => {
    setContactList(ContactList.map(client => (client.name === updatedClient.name ? updatedClient : client)));
    setSelectedContact(null);
  };

  const handleback = () => {
    setSelectedContact(null);
  };

  const backToHome = () => {
    setviewClientDetails(null);
  };

useEffect(() => {
    
  }, [viewClientDetails]);

 
  return (
    <>
      <div style={appStyle}>
        <Header/>

        {viewClientDetails ? (<>
        <ContactItem viewClientDetails={viewClientDetails} backToHome={backToHome} />
        </>
      ) : (<>
        <ContactForm selectedContact={selectedContact} addClient={addClient} updateClient={updateClient} handleback={handleback}/>
        <ContactListpage ContactList={ContactList} setSelectedContact={setSelectedContact} setviewClientDetails={setviewClientDetails} deleteClient={deleteClient}  />
      </>
      )}
        <Footer/>
      </div>
      
    </>
  )
}

export default App
