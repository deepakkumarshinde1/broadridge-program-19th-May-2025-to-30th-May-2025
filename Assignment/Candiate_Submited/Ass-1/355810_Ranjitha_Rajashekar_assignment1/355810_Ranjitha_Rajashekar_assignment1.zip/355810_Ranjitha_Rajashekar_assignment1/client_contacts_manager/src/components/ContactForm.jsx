import React,{ useEffect, useState } from 'react'

function ContactForm(props) {

  let {  selectedContact, addClient, updateClient, handleback } = props;

 const [client, setClient] = useState({ name: '', email: '', phonenumber: '' });

  useEffect(() => {
    if (selectedContact) setClient(selectedContact);
  }, [selectedContact]);

  const handleChange = (e) => {
    setClient({ ...client, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!client.name || !client.email || !client.phonenumber) return;

    if (selectedContact) {
      updateClient(client);
    } else {
      addClient(client);
    }
    setClient({ name: '', email: '', phonenumber: '' });
  };

  

  
  return (
    <div>
      <h2>Contact Form Add/Edit</h2>
       <div>
      <table>
        <tbody>
      <tr>
        <td>
      <label htmlFor="name">Name          :</label>
      </td>
      <td>
      <input
        type="text"
        id="name"
        name="name"
        placeholder="Name"
        value={client.name}
        onChange={handleChange}
      />
      </td>
      </tr>
      <tr>
        <td> 
      <label htmlFor="email">Email        :</label>
      </td>
      <td>
      <input
        type="email"
        id="email"
        name="email"
        placeholder="Email ID"
        value={client.email}
        onChange={handleChange}
      />
      </td>
      </tr>
      <tr>
      <td>
      <label htmlFor="phone">Phone Number :</label>
      </td>
      <td>
      <input
        type="tel"
        name="phonenumber"
        id="phone"
        placeholder="Phone Number"
        value={client.phonenumber}
        onChange={handleChange}
      /></td>
      </tr>
      </tbody>
      </table>
      
      <button onClick={handleSubmit}>{selectedContact ? 'Update' : 'Add'} Client</button>
      <button onClick={() => {
  handleback();
  setClient({ name: '', email: '', phonenumber: '' });
}}>Back</button>
    </div> 
    </div>
  )
}

export default ContactForm
