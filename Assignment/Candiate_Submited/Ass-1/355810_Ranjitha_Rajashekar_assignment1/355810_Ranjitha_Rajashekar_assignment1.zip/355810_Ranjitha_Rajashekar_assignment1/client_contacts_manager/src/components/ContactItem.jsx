import React,{ useEffect, useState } from 'react'

function ContactItem(props) {

  let {viewClientDetails, backToHome} = props;

 
  
  return (
    <div>
      <h2>Client Details</h2>
      <p><strong>Name:</strong> {viewClientDetails.name}</p>
      <p><strong>Email:</strong> {viewClientDetails.email}</p>
      <p><strong>Phone:</strong> {viewClientDetails.phonenumber}</p>
      <button onClick={backToHome}>Back</button>
    </div>
  )
}

export default ContactItem
