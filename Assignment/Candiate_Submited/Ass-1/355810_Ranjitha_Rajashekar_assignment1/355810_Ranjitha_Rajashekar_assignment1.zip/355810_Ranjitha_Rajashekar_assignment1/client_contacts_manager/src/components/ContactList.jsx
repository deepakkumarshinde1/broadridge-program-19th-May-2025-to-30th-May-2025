import React, { useState } from 'react';

function ContactList(props) {

 
   let {  ContactList, deleteClient, setSelectedContact, setviewClientDetails } = props;


  return (
     <div>
      <h2>Contact List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {ContactList.map((contact, index) => (
            <tr key={index}>
              <td>{contact.name}</td>
              <td>{contact.email}</td>
              <td>{contact.phonenumber}</td>
              <td>
                <button onClick={() => setSelectedContact({ name: contact.name, email: contact.email, phonenumber: contact.phonenumber })}>Edit</button>
                <button onClick={() => deleteClient(contact.name)}>Delete</button>
                <button onClick={() => setviewClientDetails({ name: contact.name, email: contact.email, phonenumber: contact.phonenumber })}>Details</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      
    </div>
  )
}

export default ContactList
