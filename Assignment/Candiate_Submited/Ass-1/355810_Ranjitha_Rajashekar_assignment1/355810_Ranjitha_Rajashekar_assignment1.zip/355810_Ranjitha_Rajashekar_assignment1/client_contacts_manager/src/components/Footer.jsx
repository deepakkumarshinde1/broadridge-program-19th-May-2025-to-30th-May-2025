import React from 'react'

function Footer() {
    
    const hrStyle = {
    border: '0',                // Remove default border
    height: '4px',              // Make the line thick
    backgroundColor: '#61dafb', // Choose any color (light blue here)
    margin: '20px 0',           // Add spacing above and below the line
  };
  return (
    <footer >
      <div>
        <hr style={hrStyle}/>
        <p>&copy; {new Date().getFullYear()} Ranjitha Rajashekar, Assignment 1</p>
      </div>
    </footer>
  )
}

export default Footer
