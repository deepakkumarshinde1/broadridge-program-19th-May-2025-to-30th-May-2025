import React from 'react'

function Header() {

const headerStyle = {
    width: '100%',
    position: 'fixed',         // Sticks to top
    top: 0,
    left: 0,
    backgroundColor:'#61dafb',
    padding: '15px 0',
    textAlign: 'center',
    zIndex: 1000
  };

    const titleStyle = {
    margin: 0,
    fontSize: '1.5em',
  };

  return (
   <header style={headerStyle}>
      <h1 style={titleStyle}>Client Contact Manager Application</h1>
    </header>
  )
}

export default Header
