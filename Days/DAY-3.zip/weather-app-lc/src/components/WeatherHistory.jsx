function WeatherHistory() {
  return <div>WeatherHistory</div>;
}

export default WeatherHistory;
