// import (optional)

import { Component } from "react";
import Counter from "./components/Counter";

// comp (class / function)
class App extends Component {
  constructor(props) {
    super(props);
    this.counterList = [1, 2, 3];
  }

  render() {
    return (
      <section>
        {this.counterList.map((value, index) => {
          return <Counter key={index} counter={value} counterName={index} />;
        })}
      </section>
    );
  }
}

export default App;

// JSX => Javascript XML

// it has only one parent
// elements must be closed
// class => className
// for => htmlFor
// javascript = {} => JSX string interpolation syntax
