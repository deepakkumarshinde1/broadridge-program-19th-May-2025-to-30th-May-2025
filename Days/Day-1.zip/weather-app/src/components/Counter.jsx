function Counter({ counter: count, counterName = "No Value" }) {
  return (
    <section>
      <h1>
        Counter:{counterName} {count}
      </h1>
    </section>
  );
}

export default Counter;
